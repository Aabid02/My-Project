Cardiac Diagnosis Fullstack - backend placeholder.

Frontend
--------
A React + Vite frontend is in `frontend/`.
Run:
```
cd frontend
npm install
npm run dev
```
By default frontend calls backend on localhost ports (9001-9004). When deploying, update API base URLs in `src/api.js`.

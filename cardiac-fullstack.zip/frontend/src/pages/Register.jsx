import React, {useState} from 'react'
import { register } from '../api'
import { useNavigate } from 'react-router-dom'
export default function Register(){ const [u,setU]=useState(''), [p,setP]=useState(''); const nav=useNavigate()
  async function go(e){ e.preventDefault(); try{ await register(u,p); alert('Registered'); nav('/login') }catch(err){ alert('Register failed') } }
  return (<div><h2>Register</h2><form onSubmit={go}><input placeholder='username' value={u} onChange={e=>setU(e.target.value)}/><br/><input placeholder='password' type='password' value={p} onChange={e=>setP(e.target.value)}/><br/><button>Register</button></form></div>)
}

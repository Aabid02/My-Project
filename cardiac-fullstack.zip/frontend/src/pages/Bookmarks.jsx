import React, {useEffect, useState} from 'react'
import { getBookmarks } from '../api'
export default function Bookmarks(){
  const [list,setList]=useState([])
  const token = localStorage.getItem('token')
  useEffect(()=>{ if(!token) return; getBookmarks(token).then(r=>setList(r)).catch(()=>{}) },[])
  if(!token) return <div>Please login</div>
  return (<div><h2>Bookmarks</h2>{list.length? list.map((it,idx)=>(<div key={idx} className='card'><div>{it.Disease || it.disease || 'Case'}</div></div>)) : <div>No bookmarks</div>}</div>)
}

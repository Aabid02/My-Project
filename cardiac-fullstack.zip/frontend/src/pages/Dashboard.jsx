import React, {useEffect, useState} from 'react'
import { getDiagnosis, addBookmark } from '../api'
export default function Dashboard(){
  const [data,setData]=useState([])
  useEffect(()=>{ getDiagnosis().then(d=>setData(d)).catch(e=>console.error(e)) },[])
  const token = localStorage.getItem('token')
  return (<div><h2>Diagnosis</h2>{data && data.length? data.map((item,idx)=>(<div key={idx} className='card'><b>{item.Disease || item.pain || 'Case'}</b><div>Age: {item.Age}</div><div>Gender: {item.Gender}</div><div>BP: {item.BP}</div><div><button onClick={()=>{ if(!token){alert('Login first'); return} addBookmark(token, item).then(()=>alert('Bookmarked'))}}>Bookmark</button></div></div>)): <div>No data</div>}</div>)
}

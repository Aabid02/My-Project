import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '../api'
export default function Login(){
  const [u,setU]=useState(''), [p,setP]=useState('')
  const nav = useNavigate()
  async function go(e){ e.preventDefault(); try{ const res = await login(u,p); localStorage.setItem('token', res.token); nav('/') }catch(err){ alert('Login failed') } }
  return (<div>
    <h2>Login</h2>
    <form onSubmit={go}>
      <input placeholder="username" value={u} onChange={e=>setU(e.target.value)}/><br/>
      <input placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)}/><br/>
      <button>Login</button>
    </form>
  </div>)
}

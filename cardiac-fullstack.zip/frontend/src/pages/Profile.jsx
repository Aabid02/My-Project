import React, {useEffect, useState} from 'react'
import { getProfile, updateProfile } from '../api'
export default function Profile(){
  const [profile,setProfile]=useState({}); const [age,setAge]=useState(''); const [gender,setGender]=useState('')
  const token = localStorage.getItem('token')
  useEffect(()=>{ if(!token) return; getProfile(token).then(p=>{ setProfile(p); setAge(p.age||''); setGender(p.gender||'') }).catch(()=>{}) },[])
  async function save(){ await updateProfile(token, {age,gender}); alert('Saved') }
  if(!token) return <div>Please login</div>
  return (<div><h2>Profile</h2><div>Username: {profile.username}</div><div><input placeholder='age' value={age} onChange={e=>setAge(e.target.value)}/></div><div><input placeholder='gender' value={gender} onChange={e=>setGender(e.target.value)}/></div><div><button onClick={save}>Save</button></div></div>)
}

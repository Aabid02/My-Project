const AUTH_BASE = "http://localhost:9001"
const DIAG_BASE = "http://localhost:9003"
const BM_BASE = "http://localhost:9004"
const PROFILE_BASE = "http://localhost:9002"

export async function login(username,password){
  const r = await fetch(`${AUTH_BASE}/api/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})})
  if(!r.ok) throw new Error('Login failed')
  return r.json()
}
export async function register(username,password){
  const r = await fetch(`${AUTH_BASE}/api/auth/register`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})})
  return r.json()
}
export async function getDiagnosis(){
  const r = await fetch(`${DIAG_BASE}/api/diagnosis`)
  return r.json()
}
export async function addBookmark(token, body){
  const r = await fetch(`${BM_BASE}/api/bookmarks`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(body)})
  return r.json()
}
export async function getBookmarks(token){
  const r = await fetch(`${BM_BASE}/api/bookmarks`,{headers:{'Authorization':'Bearer '+token}})
  return r.json()
}
export async function getProfile(token){
  const r = await fetch(`${PROFILE_BASE}/api/profile/me`,{headers:{'Authorization':'Bearer '+token}})
  return r.json()
}
export async function updateProfile(token, body){
  const r = await fetch(`${PROFILE_BASE}/api/profile/me`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(body)})
  return r.json()
}

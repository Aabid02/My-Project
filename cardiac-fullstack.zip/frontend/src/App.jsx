import React from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Profile from './pages/Profile'
import Bookmarks from './pages/Bookmarks'

function App(){
  const navigate = useNavigate()
  const token = localStorage.getItem('token')
  return (
    <div className="app">
      <nav>
        <Link to="/">Home</Link>{" | "}
        {!token ? <><Link to="/login">Login</Link>{" | "}<Link to="/register">Register</Link></> :
        <><Link to="/profile">Profile</Link>{" | "}<Link to="/bookmarks">Bookmarks</Link>{" | "}<a href="#" onClick={() => {localStorage.removeItem('token'); navigate('/')}}>Logout</a></>}
      </nav>
      <main>
        <Routes>
          <Route path="/" element={<Dashboard/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/register" element={<Register/>}/>
          <Route path="/profile" element={<Profile/>}/>
          <Route path="/bookmarks" element={<Bookmarks/>}/>
        </Routes>
      </main>
    </div>
  )
}

export default App
